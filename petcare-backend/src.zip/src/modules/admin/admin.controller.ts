import {
  Controller,
  Get,
  Patch,
  Param,
  Body,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { AdminService } from './admin.service';
import { JwtAuthGuard } from '../../guards/jwt-auth.guard';
import { RolesGuard } from '../../guards/roles.guard';
import { Roles } from '../../decorators/roles.decorator';
import { UserRole } from '../../schemas/user.schema';
import {
  DashboardQueryDto,
  SalesAnalyticsDto,
  UserAnalyticsDto,
  GetUsersDto,
  UpdateUserRoleDto,
  UpdateUserStatusDto,
  ActivityLogsDto,
  ExportReportDto,
} from './dto/admin.dto';

@Controller('admin')
@UseGuards(JwtAuthGuard, RolesGuard)
@Roles(UserRole.ADMIN)
export class AdminController {
  constructor(private readonly adminService: AdminService) {}

  // F8.1: Dashboard Overview
  @Get('dashboard')
  async getDashboard(@Query() queryDto: DashboardQueryDto) {
    return this.adminService.getDashboard(queryDto);
  }

  // F8.2: Sales Analytics
  @Get('analytics/sales')
  async getSalesAnalytics(@Query() analyticsDto: SalesAnalyticsDto) {
    return this.adminService.getSalesAnalytics(analyticsDto);
  }

  // F8.3: User Analytics
  @Get('analytics/users')
  async getUserAnalytics(@Query() analyticsDto: UserAnalyticsDto) {
    return this.adminService.getUserAnalytics(analyticsDto);
  }

  // F8.4: Get All Users
  @Get('users')
  async getAllUsers(@Query() filtersDto: GetUsersDto) {
    return this.adminService.getAllUsers(filtersDto);
  }

  // F8.5: Update User Role
  @Patch('users/:id/role')
  async updateUserRole(
    @Req() req,
    @Param('id') userId: string,
    @Body() updateDto: UpdateUserRoleDto,
  ) {
    return this.adminService.updateUserRole(req.user.userId, userId, updateDto);
  }

  // F8.6: Update User Status (Ban/Unban)
  @Patch('users/:id/status')
  async updateUserStatus(
    @Req() req,
    @Param('id') userId: string,
    @Body() updateDto: UpdateUserStatusDto,
  ) {
    return this.adminService.updateUserStatus(
      req.user.userId,
      userId,
      updateDto,
    );
  }

  // F8.7: Get Activity Logs
  @Get('activity-logs')
  async getActivityLogs(@Query() logsDto: ActivityLogsDto) {
    return this.adminService.getActivityLogs(logsDto);
  }

  // F8.8: System Health Check
  @Get('system/health')
  async getSystemHealth() {
    return this.adminService.getSystemHealth();
  }

  // F8.9: Export Reports
  @Get('reports/export')
  async exportReport(@Query() exportDto: ExportReportDto) {
    return this.adminService.exportReport(exportDto);
  }
}