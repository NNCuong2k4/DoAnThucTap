import {
  Injectable,
  NotFoundException,
  BadRequestException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { User, UserDocument } from '../../schemas/user.schema';
import { Order, OrderDocument } from '../../schemas/order.schema';
import { Product, ProductDocument } from '../../schemas/product.schema';
import { Appointment, AppointmentDocument } from '../../schemas/appointment.schema';
import { BlogPost, BlogPostDocument } from '../../schemas/blog-post.schema';
import {
  ActivityLog,
  ActivityLogDocument,
  ActivityAction,
} from '../../schemas/activity-log.schema';
import {
  DashboardQueryDto,
  SalesAnalyticsDto,
  UserAnalyticsDto,
  GetUsersDto,
  UpdateUserRoleDto,
  UpdateUserStatusDto,
  ActivityLogsDto,
  ExportReportDto,
} from './dto/admin.dto';

@Injectable()
export class AdminService {
  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    @InjectModel(Order.name) private orderModel: Model<OrderDocument>,
    @InjectModel(Product.name) private productModel: Model<ProductDocument>,
    @InjectModel(Appointment.name)
    private appointmentModel: Model<AppointmentDocument>,
    @InjectModel(BlogPost.name)
    private blogPostModel: Model<BlogPostDocument>,
    @InjectModel(ActivityLog.name)
    private activityLogModel: Model<ActivityLogDocument>,
  ) {}

  // F8.1: Dashboard Overview
  async getDashboard(queryDto: DashboardQueryDto) {
    const { period = 'today' } = queryDto;

    // Calculate date range
    const dateRange = this.calculateDateRange(period);

    // Aggregate all statistics
    const [
      totalUsers,
      totalOrders,
      totalProducts,
      totalRevenue,
      todayOrders,
      todayRevenue,
      todayUsers,
      pendingOrders,
      lowStockProducts,
      recentActivities,
      topProducts,
      ordersByStatus,
    ] = await Promise.all([
      // Total counts
      this.userModel.countDocuments(),
      this.orderModel.countDocuments(),
      this.productModel.countDocuments({ deletedAt: null }),

      // Total revenue
      this.orderModel.aggregate([
        { $match: { status: { $in: ['completed', 'delivered'] } } },
        { $group: { _id: null, total: { $sum: '$total' } } },
      ]),

      // Today's orders
      this.orderModel.countDocuments({
        createdAt: { $gte: dateRange.start, $lte: dateRange.end },
      }),

      // Today's revenue
      this.orderModel.aggregate([
        {
          $match: {
            createdAt: { $gte: dateRange.start, $lte: dateRange.end },
            status: { $in: ['completed', 'delivered'] },
          },
        },
        { $group: { _id: null, total: { $sum: '$total' } } },
      ]),

      // New users today
      this.userModel.countDocuments({
        createdAt: { $gte: dateRange.start, $lte: dateRange.end },
      }),

      // Pending orders
      this.orderModel.countDocuments({ status: 'pending' }),

      // Low stock products
      this.productModel.countDocuments({
        stock: { $lt: 10 },
        deletedAt: null,
      }),

      // Recent activities
      this.activityLogModel
        .find()
        .populate('user', 'name email')
        .sort({ createdAt: -1 })
        .limit(10)
        .exec(),

      // Top selling products
      this.orderModel.aggregate([
        { $unwind: '$items' },
        {
          $group: {
            _id: '$items.product',
            totalSold: { $sum: '$items.quantity' },
            revenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } },
          },
        },
        { $sort: { totalSold: -1 } },
        { $limit: 5 },
        {
          $lookup: {
            from: 'products',
            localField: '_id',
            foreignField: '_id',
            as: 'product',
          },
        },
        { $unwind: '$product' },
      ]),

      // Orders by status
      this.orderModel.aggregate([
        { $group: { _id: '$status', count: { $sum: 1 } } },
      ]),
    ]);

    return {
      message: 'Lấy thống kê dashboard thành công',
      data: {
        overview: {
          totalUsers,
          totalOrders,
          totalProducts,
          totalRevenue: totalRevenue[0]?.total || 0,
          todayOrders,
          todayRevenue: todayRevenue[0]?.total || 0,
          todayUsers,
          pendingOrders,
          lowStockProducts,
        },
        recentActivities: recentActivities.slice(0, 10),
        topProducts: topProducts.map((item) => ({
          product: {
            _id: item.product._id,
            name: item.product.name,
            image: item.product.images?.[0],
          },
          totalSold: item.totalSold,
          revenue: item.revenue,
        })),
        ordersByStatus: ordersByStatus.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
      },
    };
  }

  // F8.2: Sales Analytics
  async getSalesAnalytics(analyticsDto: SalesAnalyticsDto) {
    const { startDate, endDate, groupBy = 'day' } = analyticsDto;

    // Validate date range
    if (new Date(startDate) > new Date(endDate)) {
      throw new BadRequestException('startDate phải nhỏ hơn endDate');
    }

    // Get daily/weekly/monthly stats
    const dateFormat = this.getDateFormat(groupBy);

    const [dailyStats, categoryBreakdown, totalStats] = await Promise.all([
      // Daily/Weekly/Monthly revenue
      this.orderModel.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(startDate), $lte: new Date(endDate) },
            status: { $in: ['completed', 'delivered'] },
          },
        },
        {
          $group: {
            _id: { $dateToString: { format: dateFormat, date: '$createdAt' } },
            revenue: { $sum: '$total' },
            orders: { $sum: 1 },
          },
        },
        { $sort: { _id: 1 } },
      ]),

      // Revenue by category
      this.orderModel.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(startDate), $lte: new Date(endDate) },
            status: { $in: ['completed', 'delivered'] },
          },
        },
        { $unwind: '$items' },
        {
          $lookup: {
            from: 'products',
            localField: 'items.product',
            foreignField: '_id',
            as: 'productInfo',
          },
        },
        { $unwind: '$productInfo' },
        {
          $lookup: {
            from: 'categories',
            localField: 'productInfo.category',
            foreignField: '_id',
            as: 'categoryInfo',
          },
        },
        { $unwind: '$categoryInfo' },
        {
          $group: {
            _id: '$categoryInfo.name',
            revenue: { $sum: { $multiply: ['$items.price', '$items.quantity'] } },
            orders: { $sum: 1 },
          },
        },
        { $sort: { revenue: -1 } },
      ]),

      // Total stats for period
      this.orderModel.aggregate([
        {
          $match: {
            createdAt: { $gte: new Date(startDate), $lte: new Date(endDate) },
            status: { $in: ['completed', 'delivered'] },
          },
        },
        {
          $group: {
            _id: null,
            totalRevenue: { $sum: '$total' },
            totalOrders: { $sum: 1 },
          },
        },
      ]),
    ]);

    const stats = totalStats[0] || { totalRevenue: 0, totalOrders: 0 };

    return {
      message: 'Lấy phân tích doanh thu thành công',
      data: {
        dateRange: { startDate, endDate },
        totalRevenue: stats.totalRevenue,
        totalOrders: stats.totalOrders,
        averageOrderValue:
          stats.totalOrders > 0 ? stats.totalRevenue / stats.totalOrders : 0,
        dailyStats: dailyStats.map((item) => ({
          date: item._id,
          revenue: item.revenue,
          orders: item.orders,
        })),
        categoryBreakdown: categoryBreakdown.map((item) => ({
          category: item._id,
          revenue: item.revenue,
          orders: item.orders,
        })),
      },
    };
  }

  // F8.3: User Analytics
  async getUserAnalytics(analyticsDto: UserAnalyticsDto) {
    const { period = 'month' } = analyticsDto;

    const dateRange = this.calculateDateRange(period);

    const [totalUsers, activeUsers, newUsers, usersByRole, userGrowth] =
      await Promise.all([
        // Total users
        this.userModel.countDocuments(),

        // Active users (logged in last 30 days)
        this.activityLogModel.distinct('user', {
          action: ActivityAction.LOGIN,
          createdAt: { $gte: new Date(Date.now() - 30 * 24 * 60 * 60 * 1000) },
        }),

        // New users in period
        this.userModel.countDocuments({
          createdAt: { $gte: dateRange.start, $lte: dateRange.end },
        }),

        // Users by role
        this.userModel.aggregate([
          { $group: { _id: '$role', count: { $sum: 1 } } },
        ]),

        // User growth over time
        this.userModel.aggregate([
          {
            $match: {
              createdAt: { $gte: dateRange.start, $lte: dateRange.end },
            },
          },
          {
            $group: {
              _id: {
                $dateToString: { format: '%Y-%m-%d', date: '$createdAt' },
              },
              newUsers: { $sum: 1 },
            },
          },
          { $sort: { _id: 1 } },
        ]),
      ]);

    return {
      message: 'Lấy phân tích người dùng thành công',
      data: {
        totalUsers,
        activeUsers: activeUsers.length,
        newUsers,
        usersByRole: usersByRole.reduce((acc, item) => {
          acc[item._id] = item.count;
          return acc;
        }, {}),
        userGrowth: userGrowth.map((item) => ({
          date: item._id,
          newUsers: item.newUsers,
        })),
      },
    };
  }

  // F8.4: Get All Users (with filters)
  async getAllUsers(filtersDto: GetUsersDto) {
    const { page = 1, limit = 20, role, status, search } = filtersDto;

    const filter: any = {};

    if (role) {
      filter.role = role;
    }

    if (status === 'banned') {
      filter.isBanned = true;
    } else if (status === 'active') {
      filter.$or = [{ isBanned: false }, { isBanned: { $exists: false } }];
    }

    if (search) {
      filter.$or = [
        { name: { $regex: search, $options: 'i' } },
        { email: { $regex: search, $options: 'i' } },
      ];
    }

    const skip = (page - 1) * limit;

    const [users, total] = await Promise.all([
      this.userModel
        .find(filter)
        .select('-password')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.userModel.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
      message: 'Lấy danh sách người dùng thành công',
      data: users,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    };
  }

  // F8.5: Update User Role
  async updateUserRole(
    adminId: string,
    userId: string,
    updateDto: UpdateUserRoleDto,
  ) {
    if (!Types.ObjectId.isValid(userId)) {
      throw new BadRequestException('ID người dùng không hợp lệ');
    }

    const user = await this.userModel.findById(userId);

    if (!user) {
      throw new NotFoundException('Không tìm thấy người dùng');
    }

    const oldRole = user.role;
    user.role = updateDto.role;
    await user.save();

    // Log activity
    await this.logActivity(
      adminId,
      ActivityAction.UPDATE_USER_ROLE,
      'user',
      userId,
      { oldRole, newRole: updateDto.role },
    );

    return {
      message: 'Cập nhật role người dùng thành công',
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        role: user.role,
      },
    };
  }

  // F8.6: Update User Status (Ban/Unban)
  async updateUserStatus(
    adminId: string,
    userId: string,
    updateDto: UpdateUserStatusDto,
  ) {
    if (!Types.ObjectId.isValid(userId)) {
      throw new BadRequestException('ID người dùng không hợp lệ');
    }

    const user = await this.userModel.findById(userId);

    if (!user) {
      throw new NotFoundException('Không tìm thấy người dùng');
    }

    const isBanned = updateDto.status === 'banned';
    (user as any).isBanned = isBanned;

    if (isBanned && updateDto.reason) {
      (user as any).banReason = updateDto.reason;
    }

    await user.save();

    // Log activity
    await this.logActivity(
      adminId,
      isBanned ? ActivityAction.BAN_USER : ActivityAction.UNBAN_USER,
      'user',
      userId,
      { reason: updateDto.reason },
    );

    return {
      message: `${isBanned ? 'Khóa' : 'Mở khóa'} tài khoản thành công`,
      data: {
        _id: user._id,
        name: user.name,
        email: user.email,
        isBanned: (user as any).isBanned,
        banReason: (user as any).banReason,
      },
    };
  }

  // F8.7: Get Activity Logs
  async getActivityLogs(logsDto: ActivityLogsDto) {
    const { page = 1, limit = 20, userId, action, startDate, endDate } = logsDto;

    const filter: any = {};

    if (userId) {
      if (!Types.ObjectId.isValid(userId)) {
        throw new BadRequestException('userId không hợp lệ');
      }
      filter.user = new Types.ObjectId(userId);
    }

    if (action) {
      filter.action = action;
    }

    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) {
        filter.createdAt.$gte = new Date(startDate);
      }
      if (endDate) {
        filter.createdAt.$lte = new Date(endDate);
      }
    }

    const skip = (page - 1) * limit;

    const [logs, total] = await Promise.all([
      this.activityLogModel
        .find(filter)
        .populate('user', 'name email role')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.activityLogModel.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
      message: 'Lấy lịch sử hoạt động thành công',
      data: logs,
      pagination: {
        page,
        limit,
        total,
        totalPages,
      },
    };
  }

  // F8.8: System Health Check
  async getSystemHealth() {
    const [
      dbStatus,
      totalUsers,
      totalOrders,
      totalProducts,
      recentErrors,
      serverUptime,
    ] = await Promise.all([
      // Database connection status
      this.checkDatabaseConnection(),

      // Quick counts
      this.userModel.estimatedDocumentCount(),
      this.orderModel.estimatedDocumentCount(),
      this.productModel.estimatedDocumentCount(),

      // Recent failed activities
      this.activityLogModel.countDocuments({
        status: 'failed',
        createdAt: { $gte: new Date(Date.now() - 24 * 60 * 60 * 1000) },
      }),

      // Server uptime
      process.uptime(),
    ]);

    return {
      message: 'Kiểm tra trạng thái hệ thống thành công',
      data: {
        status: 'healthy',
        timestamp: new Date(),
        database: {
          status: dbStatus ? 'connected' : 'disconnected',
          collections: {
            users: totalUsers,
            orders: totalOrders,
            products: totalProducts,
          },
        },
        server: {
          uptime: `${Math.floor(serverUptime / 3600)}h ${Math.floor((serverUptime % 3600) / 60)}m`,
          nodeVersion: process.version,
          memory: {
            used: `${Math.round(process.memoryUsage().heapUsed / 1024 / 1024)}MB`,
            total: `${Math.round(process.memoryUsage().heapTotal / 1024 / 1024)}MB`,
          },
        },
        errors: {
          last24Hours: recentErrors,
        },
      },
    };
  }

  // F8.9: Export Reports
  async exportReport(exportDto: ExportReportDto) {
    const { type, startDate, endDate, format = 'csv' } = exportDto;

    let data: any[];

    switch (type) {
      case 'orders':
        data = await this.exportOrders(startDate, endDate);
        break;
      case 'users':
        data = await this.exportUsers(startDate, endDate);
        break;
      case 'products':
        data = await this.exportProducts();
        break;
      case 'revenue':
        data = await this.exportRevenue(startDate, endDate);
        break;
      case 'activities':
        data = await this.exportActivities(startDate, endDate);
        break;
      default:
        throw new BadRequestException('Loại báo cáo không hợp lệ');
    }

    if (format === 'csv') {
      const csv = this.convertToCSV(data);
      return {
        message: 'Xuất báo cáo thành công',
        data: csv,
        format: 'csv',
        filename: `${type}_report_${Date.now()}.csv`,
      };
    }

    return {
      message: 'Xuất báo cáo thành công',
      data,
      format: 'json',
      filename: `${type}_report_${Date.now()}.json`,
    };
  }

  // HELPER: Log Activity
  private async logActivity(
    userId: string,
    action: ActivityAction,
    entity: string,
    entityId: string,
    details: any,
  ) {
    try {
      await this.activityLogModel.create({
        user: new Types.ObjectId(userId),
        action,
        entity,
        entityId: new Types.ObjectId(entityId),
        details,
        status: 'success',
      });
    } catch (error) {
      // Log error but don't throw
      console.error('Failed to log activity:', error);
    }
  }

  // HELPER: Calculate date range
  private calculateDateRange(period: string) {
    const now = new Date();
    const start = new Date();

    switch (period) {
      case 'today':
        start.setHours(0, 0, 0, 0);
        break;
      case 'week':
        start.setDate(now.getDate() - 7);
        break;
      case 'month':
        start.setMonth(now.getMonth() - 1);
        break;
      case 'year':
        start.setFullYear(now.getFullYear() - 1);
        break;
    }

    return { start, end: now };
  }

  // HELPER: Get date format for grouping
  private getDateFormat(groupBy: string): string {
    switch (groupBy) {
      case 'day':
        return '%Y-%m-%d';
      case 'week':
        return '%Y-W%V';
      case 'month':
        return '%Y-%m';
      default:
        return '%Y-%m-%d';
    }
  }

  // HELPER: Check database connection
  private async checkDatabaseConnection(): Promise<boolean> {
    try {
      await this.userModel.findOne().limit(1).exec();
      return true;
    } catch (error) {
      return false;
    }
  }

  // HELPER: Export Orders
  private async exportOrders(startDate?: Date, endDate?: Date) {
    const filter: any = {};
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const orders = await this.orderModel
      .find(filter)
      .populate('user', 'name email')
      .select('orderNumber total status createdAt')
      .lean();

    return orders.map((order: any) => ({
      OrderNumber: order.orderNumber,
      CustomerName: order.user?.name || 'N/A',
      CustomerEmail: order.user?.email || 'N/A',
      Total: order.total,
      Status: order.status,
      Date: order.createdAt,
    }));
  }

  // HELPER: Export Users
  private async exportUsers(startDate?: Date, endDate?: Date) {
    const filter: any = {};
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const users = await this.userModel
      .find(filter)
      .select('name email role isBanned createdAt')
      .lean();

    return users.map((user: any) => ({
      Name: user.name,
      Email: user.email,
      Role: user.role,
      Status: user.isBanned ? 'Banned' : 'Active',
      JoinedDate: user.createdAt,
    }));
  }

  // HELPER: Export Products
  private async exportProducts() {
    const products = await this.productModel
      .find({ deletedAt: null })
      .populate('category', 'name')
      .select('name price stock category')
      .lean();

    return products.map((product: any) => ({
      Name: product.name,
      Price: product.price,
      Stock: product.stock,
      Category: product.category?.name || 'N/A',
    }));
  }

  // HELPER: Export Revenue
  private async exportRevenue(startDate?: Date, endDate?: Date) {
    const filter: any = { status: { $in: ['completed', 'delivered'] } };
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const revenue = await this.orderModel.aggregate([
      { $match: filter },
      {
        $group: {
          _id: { $dateToString: { format: '%Y-%m-%d', date: '$createdAt' } },
          totalRevenue: { $sum: '$total' },
          orderCount: { $sum: 1 },
        },
      },
      { $sort: { _id: 1 } },
    ]);

    return revenue.map((item) => ({
      Date: item._id,
      Revenue: item.totalRevenue,
      Orders: item.orderCount,
    }));
  }

  // HELPER: Export Activities
  private async exportActivities(startDate?: Date, endDate?: Date) {
    const filter: any = {};
    if (startDate || endDate) {
      filter.createdAt = {};
      if (startDate) filter.createdAt.$gte = new Date(startDate);
      if (endDate) filter.createdAt.$lte = new Date(endDate);
    }

    const activities = await this.activityLogModel
      .find(filter)
      .populate('user', 'name email')
      .select('action entity status createdAt')
      .limit(1000)
      .lean();

    return activities.map((activity: any) => ({
      User: activity.user?.name || 'N/A',
      Email: activity.user?.email || 'N/A',
      Action: activity.action,
      Entity: activity.entity,
      Status: activity.status,
      Date: activity.createdAt,
    }));
  }

  // HELPER: Convert to CSV
  private convertToCSV(data: any[]): string {
    if (!data || data.length === 0) {
      return '';
    }

    const headers = Object.keys(data[0]);
    const csvRows = [headers.join(',')];

    for (const row of data) {
      const values = headers.map((header) => {
        const value = row[header];
        return `"${value}"`;
      });
      csvRows.push(values.join(','));
    }

    return csvRows.join('\n');
  }
}