import {
  IsOptional,
  IsEnum,
  IsString,
  IsNumber,
  IsDate,
  IsIn,
  Min,
  Max,
  IsMongoId,
  MinLength,
} from 'class-validator';
import { Type } from 'class-transformer';
import { UserRole } from '../../../schemas/user.schema';
import { ActivityAction } from '../../../schemas/activity-log.schema';

// DTO 1: Dashboard Query
export class DashboardQueryDto {
  @IsOptional()
  @IsIn(['today', 'week', 'month', 'year'], {
    message: 'period phải là today, week, month hoặc year',
  })
  period?: 'today' | 'week' | 'month' | 'year';
}

// DTO 2: Sales Analytics
export class SalesAnalyticsDto {
  @Type(() => Date)
  @IsDate({ message: 'startDate phải là ngày hợp lệ' })
  startDate: Date;

  @Type(() => Date)
  @IsDate({ message: 'endDate phải là ngày hợp lệ' })
  endDate: Date;

  @IsOptional()
  @IsIn(['day', 'week', 'month'], {
    message: 'groupBy phải là day, week hoặc month',
  })
  groupBy?: 'day' | 'week' | 'month';
}

// DTO 3: User Analytics
export class UserAnalyticsDto {
  @IsOptional()
  @IsIn(['week', 'month', 'year'], {
    message: 'period phải là week, month hoặc year',
  })
  period?: 'week' | 'month' | 'year';
}

// DTO 4: Get Users (with filters)
export class GetUsersDto {
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number = 1;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(100)
  limit?: number = 20;

  @IsOptional()
  @IsEnum(UserRole, { message: 'role không hợp lệ' })
  role?: UserRole;

  @IsOptional()
  @IsIn(['active', 'banned'], { message: 'status phải là active hoặc banned' })
  status?: 'active' | 'banned';

  @IsOptional()
  @IsString()
  @MinLength(2, { message: 'search phải có ít nhất 2 ký tự' })
  search?: string;
}

// DTO 5: Update User Role
export class UpdateUserRoleDto {
  @IsEnum(UserRole, { message: 'role phải là user hoặc admin' })
  role: UserRole;
}

// DTO 6: Update User Status (Ban/Unban)
export class UpdateUserStatusDto {
  @IsIn(['active', 'banned'], { message: 'status phải là active hoặc banned' })
  status: 'active' | 'banned';

  @IsOptional()
  @IsString()
  @MinLength(10, { message: 'reason phải có ít nhất 10 ký tự' })
  reason?: string;
}

// DTO 7: Activity Logs Query
export class ActivityLogsDto {
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number = 1;

  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  @Max(100)
  limit?: number = 20;

  @IsOptional()
  @IsMongoId({ message: 'userId phải là ObjectId hợp lệ' })
  userId?: string;

  @IsOptional()
  @IsEnum(ActivityAction, { message: 'action không hợp lệ' })
  action?: ActivityAction;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  startDate?: Date;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  endDate?: Date;
}

// DTO 8: Export Report
export class ExportReportDto {
  @IsIn(['orders', 'users', 'products', 'revenue', 'activities'], {
    message: 'type phải là orders, users, products, revenue hoặc activities',
  })
  type: 'orders' | 'users' | 'products' | 'revenue' | 'activities';

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  startDate?: Date;

  @IsOptional()
  @Type(() => Date)
  @IsDate()
  endDate?: Date;

  @IsOptional()
  @IsIn(['csv', 'json'], { message: 'format phải là csv hoặc json' })
  format?: 'csv' | 'json';
}