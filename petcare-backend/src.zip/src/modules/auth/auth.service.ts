import { 
  Injectable, 
  UnauthorizedException, 
  ConflictException, 
  BadRequestException,
  InternalServerErrorException,
  Logger
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model } from 'mongoose';
import { JwtService } from '@nestjs/jwt';
import * as bcrypt from 'bcryptjs';
import { User, UserDocument } from '../../schemas/user.schema';
import { RegisterDto } from '../../dto/register.dto';
import { LoginDto } from '../../dto/login.dto';
import { UpdateProfileDto } from '../../dto/update-profile.dto';

@Injectable()
export class AuthService {
  private readonly logger = new Logger(AuthService.name);

  constructor(
    @InjectModel(User.name) private userModel: Model<UserDocument>,
    private jwtService: JwtService,
  ) {}

  async register(registerDto: RegisterDto) {
    const { email, password, name, phone, address } = registerDto;

    const existingUser = await this.userModel.findOne({ email });
    if (existingUser) {
      throw new ConflictException('Email đã được sử dụng');
    }

    const hashedPassword = await bcrypt.hash(password, 10);

    const user = new this.userModel({
      name,
      email,
      password: hashedPassword,
      phone,
      address,
    });

    await user.save();

    const token = await this.generateToken(user);

    return {
      message: 'Đăng ký thành công',
      user: this.sanitizeUser(user),
      token,
    };
  }

  async login(loginDto: LoginDto) {
    const { email, password } = loginDto;

    const user = await this.userModel.findOne({ email });
    if (!user) {
      throw new UnauthorizedException('Email hoặc mật khẩu không đúng');
    }

    // Check if user is banned
    if ((user as any).isBanned) {
      throw new UnauthorizedException(
        `Tài khoản đã bị khóa. Lý do: ${(user as any).banReason || 'Vi phạm chính sách'}`,
      );
    }

    // BACKWARD COMPATIBLE: Support both 'password' and 'passwordHash'
    const userObj = user.toObject();
    const storedPassword = (userObj as any).password || (userObj as any).passwordHash;
    
    if (!storedPassword) {
      throw new UnauthorizedException('Dữ liệu người dùng không hợp lệ');
    }

    const isPasswordValid = await bcrypt.compare(password, storedPassword);
    if (!isPasswordValid) {
      throw new UnauthorizedException('Email hoặc mật khẩu không đúng');
    }

    const token = await this.generateToken(user);

    return {
      message: 'Đăng nhập thành công',
      user: this.sanitizeUser(user),
      token,
    };
  }

  async getProfile(userId: string) {
    try {
      this.logger.log(`Getting profile for user: ${userId}`);
      
      const user = await this.userModel.findById(userId).select('-password -passwordHash');
      
      if (!user) {
        throw new BadRequestException('Người dùng không tồn tại');
      }

      const userObj = user.toObject();

      return {
        message: 'Lấy thông tin người dùng thành công',
        user: {
          id: userObj._id,
          name: userObj.name,
          email: userObj.email,
          phone: userObj.phone || null,
          address: userObj.address || null,
          dateOfBirth: userObj.dateOfBirth || null,
          avatar: userObj.avatar || null,
          role: userObj.role,
          isBanned: userObj.isBanned || false,
          createdAt: userObj.createdAt,
          updatedAt: userObj.updatedAt,
        },
      };
    } catch (error) {
      this.logger.error(`Error getting profile: ${error.message}`, error.stack);
      throw error;
    }
  }

  async updateProfile(userId: string, updateProfileDto: UpdateProfileDto) {
    try {
      this.logger.log(`Updating profile for user: ${userId}`);
      this.logger.debug(`Update data: ${JSON.stringify(updateProfileDto)}`);

      // Find user
      const user = await this.userModel.findById(userId);
      if (!user) {
        throw new BadRequestException('Người dùng không tồn tại');
      }

      // Update fields if provided
      if (updateProfileDto.name !== undefined) {
        user.name = updateProfileDto.name;
        this.logger.debug(`Updated name: ${updateProfileDto.name}`);
      }
      
      if (updateProfileDto.phone !== undefined) {
        user.phone = updateProfileDto.phone;
        this.logger.debug(`Updated phone: ${updateProfileDto.phone}`);
      }
      
      if (updateProfileDto.address !== undefined) {
        user.address = updateProfileDto.address;
        this.logger.debug(`Updated address: ${updateProfileDto.address}`);
      }
      
      if (updateProfileDto.dateOfBirth !== undefined) {
        try {
          user.dateOfBirth = new Date(updateProfileDto.dateOfBirth);
          this.logger.debug(`Updated dateOfBirth: ${user.dateOfBirth}`);
        } catch (dateError) {
          this.logger.error(`Invalid date format: ${updateProfileDto.dateOfBirth}`);
          throw new BadRequestException('Định dạng ngày sinh không hợp lệ');
        }
      }
      
      if (updateProfileDto.avatar !== undefined) {
        (user as any).avatar = updateProfileDto.avatar;
        this.logger.debug(`Updated avatar: ${updateProfileDto.avatar}`);
      }

      // FIXED: Save with validateModifiedOnly option
      // Only validate fields that were actually modified, skip password validation
      await user.save({ validateModifiedOnly: true });
      this.logger.log(`Profile updated successfully for user: ${userId}`);

      // Return updated user
      const userObj = user.toObject();

      return {
        message: 'Cập nhật thông tin thành công',
        user: {
          id: userObj._id,
          name: userObj.name,
          email: userObj.email,
          phone: userObj.phone || null,
          address: userObj.address || null,
          dateOfBirth: userObj.dateOfBirth || null,
          avatar: userObj.avatar || null,
          role: userObj.role,
          createdAt: userObj.createdAt,
          updatedAt: userObj.updatedAt,
        },
      };
    } catch (error) {
      this.logger.error(`Error updating profile: ${error.message}`, error.stack);
      
      // Re-throw known errors
      if (
        error instanceof BadRequestException ||
        error instanceof UnauthorizedException
      ) {
        throw error;
      }
      
      // Wrap unknown errors
      throw new InternalServerErrorException(
        'Có lỗi xảy ra khi cập nhật thông tin. Vui lòng thử lại sau.',
      );
    }
  }

  async changePassword(userId: string, oldPassword: string, newPassword: string) {
    const user = await this.userModel.findById(userId);
    if (!user) {
      throw new BadRequestException('Người dùng không tồn tại');
    }

    const userObj = user.toObject();
    const storedPassword = (userObj as any).password || (userObj as any).passwordHash;

    if (!storedPassword) {
      throw new UnauthorizedException('Dữ liệu người dùng không hợp lệ');
    }

    const isOldPasswordValid = await bcrypt.compare(oldPassword, storedPassword);
    if (!isOldPasswordValid) {
      throw new UnauthorizedException('Mật khẩu cũ không đúng');
    }

    const hashedNewPassword = await bcrypt.hash(newPassword, 10);
    (user as any).password = hashedNewPassword;
    await user.save();

    return {
      message: 'Đổi mật khẩu thành công',
    };
  }

  private async generateToken(user: UserDocument) {
    const payload = {
      sub: user._id,
      email: user.email,
      role: user.role,
    };

    return {
      accessToken: this.jwtService.sign(payload),
      expiresIn: '7d',
    };
  }

  private sanitizeUser(user: UserDocument) {
    const userObj = user.toObject();
    const { password, passwordHash, refreshToken, ...sanitized } = userObj as any;
    return sanitized;
  }

  async validateUser(userId: string) {
    const user = await this.userModel.findById(userId);
    
    if (user && (user as any).isBanned) {
      throw new UnauthorizedException('Tài khoản đã bị khóa');
    }
    
    return user;
  }
}