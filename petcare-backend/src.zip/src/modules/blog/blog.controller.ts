import {
  Controller,
  Get,
  Post,
  Put,
  Delete,
  Body,
  Param,
  Query,
  UseGuards,
  Req,
} from '@nestjs/common';
import { BlogService } from './blog.service';
import { JwtAuthGuard } from '../../guards/jwt-auth.guard';
import { RolesGuard } from '../../guards/roles.guard';
import { Roles } from '../../decorators/roles.decorator';
import { UserRole } from '../../schemas/user.schema';
import {
  CreatePostDto,
  UpdatePostDto,
  FilterPostsDto,
  SearchPostsDto,
} from './dto/blog.dto';

@Controller('blog')
export class BlogController {
  constructor(private readonly blogService: BlogService) {}

  // F7.3: Search posts (Public) - MUST be before /:slug
  @Get('search')
  async searchPosts(@Query() searchDto: SearchPostsDto) {
    return this.blogService.searchPosts(searchDto, false);
  }

  // F7.1: Get all posts (Public)
  @Get()
  async getAllPosts(@Query() filterDto: FilterPostsDto) {
    return this.blogService.getAllPosts(filterDto, false);
  }

  // F7.4: Create post (Admin)
  @Post()
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN)
  async createPost(@Req() req, @Body() createDto: CreatePostDto) {
    return this.blogService.createPost(req.user.userId, createDto);
  }

  // F7.2: Get post detail by slug (Public)
  @Get(':slug')
  async getPostBySlug(@Param('slug') slug: string) {
    return this.blogService.getPostBySlug(slug, false);
  }

  // F7.5: Update post (Admin)
  @Put(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN)
  async updatePost(@Param('id') id: string, @Body() updateDto: UpdatePostDto) {
    return this.blogService.updatePost(id, updateDto);
  }

  // F7.6: Delete post (Admin)
  @Delete(':id')
  @UseGuards(JwtAuthGuard, RolesGuard)
  @Roles(UserRole.ADMIN)
  async deletePost(@Param('id') id: string) {
    return this.blogService.deletePost(id);
  }

  // BONUS: Get popular posts (Public)
  @Get('popular/posts')
  async getPopularPosts(@Query('limit') limit?: number) {
    const posts = await this.blogService.getPopularPosts(limit || 5);
    return {
      message: 'Lấy danh sách bài viết phổ biến thành công',
      data: posts,
    };
  }

  // BONUS: Get related posts (Public)
  @Get(':id/related')
  async getRelatedPosts(@Param('id') id: string, @Query('limit') limit?: number) {
    const posts = await this.blogService.getRelatedPosts(id, limit || 3);
    return {
      message: 'Lấy danh sách bài viết liên quan thành công',
      data: posts,
    };
  }
}