import {
  IsNotEmpty,
  IsString,
  IsEnum,
  IsOptional,
  IsNumber,
  ValidateNested,
  Min,
  IsMongoId,
} from 'class-validator';
import { ApiProperty } from '@nestjs/swagger';
import { Type } from 'class-transformer';
import { PaymentMethod, OrderStatus } from '../../../schemas/order.schema';

export class ShippingAddressDto {
  @ApiProperty({ example: 'Nguyễn Văn A', description: 'Họ tên người nhận' })
  @IsNotEmpty()
  @IsString()
  fullName: string;

  @ApiProperty({ example: '0901234567', description: 'Số điện thoại' })
  @IsNotEmpty()
  @IsString()
  phone: string;

  @ApiProperty({ example: '123 Đường ABC', description: 'Địa chỉ chi tiết' })
  @IsNotEmpty()
  @IsString()
  address: string;

  @ApiProperty({ example: 'Hồ Chí Minh', description: 'Thành phố' })
  @IsNotEmpty()
  @IsString()
  city: string;

  @ApiProperty({ example: 'Quận 1', description: 'Quận/Huyện' })
  @IsNotEmpty()
  @IsString()
  district: string;

  @ApiProperty({ example: 'Phường Bến Nghé', description: 'Phường/Xã', required: false })
  @IsOptional()
  @IsString()
  ward?: string;

  @ApiProperty({ example: 'Gọi trước khi giao', description: 'Ghi chú', required: false })
  @IsOptional()
  @IsString()
  note?: string;
}

export class CreateOrderDto {
  @ApiProperty({ type: ShippingAddressDto })
  @ValidateNested()
  @Type(() => ShippingAddressDto)
  shippingAddress: ShippingAddressDto;

  @ApiProperty({
    enum: PaymentMethod,
    example: PaymentMethod.COD,
    description: 'Phương thức thanh toán',
  })
  @IsNotEmpty()
  @IsEnum(PaymentMethod)
  paymentMethod: PaymentMethod;

  @ApiProperty({ example: 'Giao hàng nhanh', required: false })
  @IsOptional()
  @IsString()
  note?: string;
}

export class UpdateOrderStatusDto {
  @ApiProperty({
    enum: OrderStatus,
    example: OrderStatus.CONFIRMED,
    description: 'Trạng thái mới',
  })
  @IsNotEmpty()
  @IsEnum(OrderStatus)
  status: OrderStatus;

  @ApiProperty({ example: 'Đơn hàng đã được xác nhận', required: false })
  @IsOptional()
  @IsString()
  note?: string;
}

export class CancelOrderDto {
  @ApiProperty({ example: 'Đổi ý không mua nữa', description: 'Lý do hủy' })
  @IsNotEmpty()
  @IsString()
  reason: string;
}

export class FilterOrderDto {
  @ApiProperty({ example: 1, required: false })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  page?: number = 1;

  @ApiProperty({ example: 10, required: false })
  @IsOptional()
  @Type(() => Number)
  @IsNumber()
  @Min(1)
  limit?: number = 10;

  @ApiProperty({ enum: OrderStatus, required: false })
  @IsOptional()
  @IsEnum(OrderStatus)
  status?: OrderStatus;

  @ApiProperty({ example: '674471234567890abcdef123', required: false })
  @IsOptional()
  @IsMongoId()
  userId?: string;

  @ApiProperty({ example: 'ORD1732555555001', required: false })
  @IsOptional()
  @IsString()
  orderNumber?: string;
}