import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Order, OrderDocument, OrderStatus, PaymentStatus } from '../../schemas/order.schema';
import { Product, ProductDocument } from '../../schemas/product.schema';
import { CreateOrderDto, UpdateOrderStatusDto, CancelOrderDto, FilterOrderDto } from './dto/order.dto';
import { CartService } from '../cart/cart.service';

@Injectable()
export class OrdersService {
  constructor(
    @InjectModel(Order.name) private orderModel: Model<OrderDocument>,
    @InjectModel(Product.name) private productModel: Model<ProductDocument>,
    private cartService: CartService,
  ) {}

  // F4.6: Create order (Checkout)
  async createOrder(userId: string, createOrderDto: CreateOrderDto) {
    // Get cart and verify
    const cart = await this.cartService.getCartForCheckout(userId);

    if (!cart || cart.items.length === 0) {
      throw new BadRequestException('Giỏ hàng trống');
    }

    // Prepare order items
    const orderItems = cart.items.map((item: any) => ({
      productId: item.productId._id,
      name: item.productId.name,
      quantity: item.quantity,
      price: item.price,
      image: item.productId.images?.[0] || '',
    }));

    // Calculate totals
    const subtotal = cart.totalPrice;
    const shippingFee = this.calculateShippingFee(createOrderDto.shippingAddress.city);
    const discount = 0; // TODO: Apply voucher/coupon logic
    const total = subtotal + shippingFee - discount;

    // Generate order number
    const timestamp = Date.now();
    const random = Math.floor(Math.random() * 1000).toString().padStart(3, '0');
    const orderNumber = `ORD${timestamp}${random}`;

    // Create order
    const order = new this.orderModel({
      orderNumber,
      userId: new Types.ObjectId(userId),
      items: orderItems,
      shippingAddress: createOrderDto.shippingAddress,
      paymentMethod: createOrderDto.paymentMethod,
      paymentStatus: PaymentStatus.PENDING,
      status: OrderStatus.PENDING,
      statusHistory: [
        {
          status: OrderStatus.PENDING,
          timestamp: new Date(),
          note: 'Đơn hàng đã được tạo',
        },
      ],
      subtotal,
      shippingFee,
      discount,
      total,
      note: createOrderDto.note,
    });

    await order.save();

    // Update product stock
    for (const item of cart.items) {
      await this.productModel.findByIdAndUpdate(
        item.productId,
        { $inc: { stock: -item.quantity, soldCount: item.quantity } },
      );
    }

    // Clear cart
    await this.cartService.clearCart(userId);

    return {
      message: 'Đặt hàng thành công',
      data: order,
    };
  }

  // F4.7: Get my orders
  async getMyOrders(userId: string, filterDto: FilterOrderDto) {
    const { page = 1, limit = 10, status } = filterDto;

    const filter: any = { userId };
    if (status) {
      filter.status = status;
    }

    const skip = (page - 1) * limit;

    const [orders, total] = await Promise.all([
      this.orderModel
        .find(filter)
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.orderModel.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
      message: 'Lấy danh sách đơn hàng thành công',
      data: orders,
      pagination: {
        page,
        limit,
        total,
        totalPages,
        hasNextPage: page < totalPages,
        hasPrevPage: page > 1,
      },
    };
  }

  // F4.8: Get order detail
  async getOrderDetail(userId: string, orderId: string, isAdmin: boolean = false) {
    if (!Types.ObjectId.isValid(orderId)) {
      throw new BadRequestException('ID đơn hàng không hợp lệ');
    }

    const order = await this.orderModel.findById(orderId);

    if (!order) {
      throw new NotFoundException('Không tìm thấy đơn hàng');
    }

    // Check ownership (unless admin)
    if (!isAdmin && order.userId.toString() !== userId) {
      throw new ForbiddenException('Bạn không có quyền xem đơn hàng này');
    }

    return {
      message: 'Lấy thông tin đơn hàng thành công',
      data: order,
    };
  }

  // F4.9: Cancel order (user)
  async cancelOrder(userId: string, orderId: string, cancelDto: CancelOrderDto) {
    const order = await this.orderModel.findById(orderId);

    if (!order) {
      throw new NotFoundException('Không tìm thấy đơn hàng');
    }

    // Check ownership
    if (order.userId.toString() !== userId) {
      throw new ForbiddenException('Bạn không có quyền hủy đơn hàng này');
    }

    // Check if can cancel
    const cannotCancelStatuses = [
      OrderStatus.SHIPPING,
      OrderStatus.DELIVERED,
      OrderStatus.CANCELLED,
      OrderStatus.REFUNDED,
    ];

    if (cannotCancelStatuses.includes(order.status)) {
      throw new BadRequestException(
        `Không thể hủy đơn hàng ở trạng thái ${order.status}`,
      );
    }

    // Update order
    order.status = OrderStatus.CANCELLED;
    order.cancelReason = cancelDto.reason;
    order.cancelledAt = new Date();

    order.statusHistory.push({
      status: OrderStatus.CANCELLED,
      timestamp: new Date(),
      note: `Đơn hàng bị hủy. Lý do: ${cancelDto.reason}`,
      updatedBy: new Types.ObjectId(userId),
    });

    await order.save();

    // Restore product stock
    for (const item of order.items) {
      await this.productModel.findByIdAndUpdate(
        item.productId,
        { $inc: { stock: item.quantity, soldCount: -item.quantity } },
      );
    }

    return {
      message: 'Hủy đơn hàng thành công',
      data: order,
    };
  }

  // F4.10: Update order status (Admin)
  async updateOrderStatus(
    adminId: string,
    orderId: string,
    updateDto: UpdateOrderStatusDto,
  ) {
    const order = await this.orderModel.findById(orderId);

    if (!order) {
      throw new NotFoundException('Không tìm thấy đơn hàng');
    }

    // Cannot update cancelled orders
    if (order.status === OrderStatus.CANCELLED) {
      throw new BadRequestException('Không thể cập nhật đơn hàng đã hủy');
    }

    // Validate status transition
    this.validateStatusTransition(order.status, updateDto.status);

    // Update status
    order.status = updateDto.status;

    if (updateDto.status === OrderStatus.DELIVERED) {
      order.deliveredAt = new Date();
      order.paymentStatus = PaymentStatus.PAID;
    }

    order.statusHistory.push({
      status: updateDto.status,
      timestamp: new Date(),
      note: updateDto.note || `Đơn hàng chuyển sang trạng thái ${updateDto.status}`,
      updatedBy: new Types.ObjectId(adminId),
    });

    await order.save();

    return {
      message: 'Cập nhật trạng thái đơn hàng thành công',
      data: order,
    };
  }

  // F4.11: Get all orders (Admin)
  async getAllOrders(filterDto: FilterOrderDto) {
    const { page = 1, limit = 20, status, userId, orderNumber } = filterDto;

    const filter: any = {};
    if (status) filter.status = status;
    if (userId) filter.userId = userId;
    if (orderNumber) filter.orderNumber = orderNumber;

    const skip = (page - 1) * limit;

    const [orders, total] = await Promise.all([
      this.orderModel
        .find(filter)
        .populate('userId', 'name email phone')
        .sort({ createdAt: -1 })
        .skip(skip)
        .limit(limit)
        .exec(),
      this.orderModel.countDocuments(filter),
    ]);

    const totalPages = Math.ceil(total / limit);

    return {
      message: 'Lấy danh sách đơn hàng thành công',
      data: orders,
      pagination: {
        page,
        limit,
        total,
        totalPages,
      },
    };
  }

  // F4.12: Get statistics (Admin)
  async getStatistics() {
    const [
      totalOrders,
      pendingOrders,
      confirmedOrders,
      processingOrders,
      shippingOrders,
      deliveredOrders,
      cancelledOrders,
      totalRevenue,
    ] = await Promise.all([
      this.orderModel.countDocuments(),
      this.orderModel.countDocuments({ status: OrderStatus.PENDING }),
      this.orderModel.countDocuments({ status: OrderStatus.CONFIRMED }),
      this.orderModel.countDocuments({ status: OrderStatus.PROCESSING }),
      this.orderModel.countDocuments({ status: OrderStatus.SHIPPING }),
      this.orderModel.countDocuments({ status: OrderStatus.DELIVERED }),
      this.orderModel.countDocuments({ status: OrderStatus.CANCELLED }),
      this.orderModel.aggregate([
        { $match: { status: OrderStatus.DELIVERED } },
        { $group: { _id: null, total: { $sum: '$total' } } },
      ]),
    ]);

    return {
      message: 'Lấy thống kê thành công',
      data: {
        totalOrders,
        ordersByStatus: {
          pending: pendingOrders,
          confirmed: confirmedOrders,
          processing: processingOrders,
          shipping: shippingOrders,
          delivered: deliveredOrders,
          cancelled: cancelledOrders,
        },
        totalRevenue: totalRevenue[0]?.total || 0,
      },
    };
  }

  // Helper: Calculate shipping fee
  private calculateShippingFee(city: string): number {
    const cityLower = city.toLowerCase();
    
    if (cityLower.includes('hồ chí minh') || cityLower.includes('hà nội')) {
      return 30000; // 30k for major cities
    }
    
    return 50000; // 50k for other cities
  }

  // Helper: Validate status transition
  private validateStatusTransition(currentStatus: OrderStatus, newStatus: OrderStatus) {
    const validTransitions: Record<OrderStatus, OrderStatus[]> = {
      [OrderStatus.PENDING]: [OrderStatus.CONFIRMED, OrderStatus.CANCELLED],
      [OrderStatus.CONFIRMED]: [OrderStatus.PROCESSING, OrderStatus.CANCELLED],
      [OrderStatus.PROCESSING]: [OrderStatus.SHIPPING, OrderStatus.CANCELLED],
      [OrderStatus.SHIPPING]: [OrderStatus.DELIVERED],
      [OrderStatus.DELIVERED]: [OrderStatus.REFUNDED],
      [OrderStatus.CANCELLED]: [],
      [OrderStatus.REFUNDED]: [],
    };

    const allowedStatuses = validTransitions[currentStatus];
    if (!allowedStatuses || !allowedStatuses.includes(newStatus)) {
      throw new BadRequestException(
        `Không thể chuyển từ trạng thái ${currentStatus} sang ${newStatus}`,
      );
    }
  }
}