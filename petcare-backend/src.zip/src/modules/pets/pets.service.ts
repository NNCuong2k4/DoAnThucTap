import {
  Injectable,
  NotFoundException,
  BadRequestException,
  ForbiddenException,
} from '@nestjs/common';
import { InjectModel } from '@nestjs/mongoose';
import { Model, Types } from 'mongoose';
import { Pet, PetDocument } from '../../schemas/pet.schema';
import { CreatePetDto } from './dto/create-pet.dto';
import { UpdatePetDto } from './dto/update-pet.dto';
import { AddVaccinationDto, UpdateVaccinationDto } from './dto/add-vaccination.dto';
import { AddMedicalRecordDto } from './dto/add-medical-record.dto';

@Injectable()
export class PetsService {
  constructor(
    @InjectModel(Pet.name)
    private petModel: Model<PetDocument>,
  ) {}

  // Get all pets (Admin)
  async findAll() {
    return await this.petModel.find({ isActive: true }).sort({ createdAt: -1 });
  }

  // ⭐ NEW: Get user's pets (PRIORITY HIGH)
  async findMyPets(userId: string) {
    return await this.petModel
      .find({
        ownerId: new Types.ObjectId(userId),
        isActive: true,
      })
      .sort({ createdAt: -1 });
  }

  // Get single pet
  async findOne(userId: string, petId: string) {
    if (!Types.ObjectId.isValid(petId)) {
      throw new BadRequestException('ID thú cưng không hợp lệ');
    }

    const pet = await this.petModel.findOne({
      _id: petId,
      ownerId: userId,
      isActive: true,
    });

    if (!pet) {
      throw new NotFoundException('Không tìm thấy thú cưng');
    }

    return pet;
  }

  // Create pet
  async create(userId: string, createPetDto: CreatePetDto) {
    const petData: any = {
      ...createPetDto,
      ownerId: new Types.ObjectId(userId),
    };

    if (createPetDto.dob) {
      petData.dob = new Date(createPetDto.dob);
    }

    const pet = new this.petModel(petData);
    return await pet.save();
  }

  // Update pet
  async update(userId: string, petId: string, updatePetDto: UpdatePetDto) {
    const pet = await this.findOne(userId, petId);

    Object.keys(updatePetDto).forEach((key) => {
      if (updatePetDto[key] !== undefined) {
        if (key === 'dob' && updatePetDto[key]) {
          pet[key] = new Date(updatePetDto[key]);
        } else {
          pet[key] = updatePetDto[key];
        }
      }
    });

    return await pet.save({ validateModifiedOnly: true });
  }

  // Delete pet (soft delete)
  async delete(userId: string, petId: string) {
    const pet = await this.findOne(userId, petId);
    pet.isActive = false;
    await pet.save({ validateModifiedOnly: true });
    return { message: 'Xóa thú cưng thành công' };
  }

  // ⭐ NEW: Verify ownership helper
  async verifyOwnership(petId: string, userId: string): Promise<PetDocument> {
    if (!Types.ObjectId.isValid(petId)) {
      throw new BadRequestException('ID thú cưng không hợp lệ');
    }

    const pet = await this.petModel.findOne({
      _id: petId,
      ownerId: new Types.ObjectId(userId),
      isActive: true,
    });

    if (!pet) {
      throw new NotFoundException('Không tìm thấy thú cưng hoặc bạn không có quyền truy cập');
    }

    return pet;
  }

  // ==================== VACCINATIONS ====================

  // Get vaccinations
  async getVaccinations(userId: string, petId: string) {
    const pet = await this.verifyOwnership(petId, userId);
    return {
      petId: pet._id,
      petName: pet.name,
      vaccinations: pet.vaccinations,
    };
  }

  // ⭐ NEW: Add vaccination (PRIORITY MEDIUM)
  async addVaccination(
    userId: string,
    petId: string,
    addVaccinationDto: AddVaccinationDto,
  ) {
    const pet = await this.verifyOwnership(petId, userId);

    const vaccination = {
      _id: new Types.ObjectId(),
      name: addVaccinationDto.name,
      date: new Date(addVaccinationDto.date),
      nextDue: addVaccinationDto.nextDue
        ? new Date(addVaccinationDto.nextDue)
        : undefined,
      notes: addVaccinationDto.notes || '',
    };

    pet.vaccinations.push(vaccination as any);
    await pet.save({ validateModifiedOnly: true });

    return {
      vaccination,
      pet,
    };
  }

  // ⭐ NEW: Update vaccination (PRIORITY LOW)
  async updateVaccination(
    userId: string,
    petId: string,
    vaccinationId: string,
    updateVaccinationDto: UpdateVaccinationDto,
  ) {
    const pet = await this.verifyOwnership(petId, userId);

    // ✅ FIX: Access _id from vaccination object
    const vaccination = pet.vaccinations.find(
      (v: any) => v._id.toString() === vaccinationId,
    );

    if (!vaccination) {
      throw new NotFoundException('Không tìm thấy lịch sử tiêm phòng');
    }

    if (updateVaccinationDto.name !== undefined) {
      vaccination.name = updateVaccinationDto.name;
    }
    if (updateVaccinationDto.date !== undefined) {
      vaccination.date = new Date(updateVaccinationDto.date);
    }
    if (updateVaccinationDto.nextDue !== undefined) {
      vaccination.nextDue = new Date(updateVaccinationDto.nextDue);
    }
    if (updateVaccinationDto.notes !== undefined) {
      vaccination.notes = updateVaccinationDto.notes;
    }

    await pet.save({ validateModifiedOnly: true });

    return { vaccination };
  }

  // ⭐ NEW: Delete vaccination (PRIORITY LOW)
  async deleteVaccination(userId: string, petId: string, vaccinationId: string) {
    const pet = await this.verifyOwnership(petId, userId);

    // ✅ FIX: Access _id from vaccination object
    const vaccinationIndex = pet.vaccinations.findIndex(
      (v: any) => v._id.toString() === vaccinationId,
    );

    if (vaccinationIndex === -1) {
      throw new NotFoundException('Không tìm thấy lịch sử tiêm phòng');
    }

    pet.vaccinations.splice(vaccinationIndex, 1);
    await pet.save({ validateModifiedOnly: true });

    return { message: 'Xóa lịch sử tiêm phòng thành công' };
  }

  // ==================== MEDICAL HISTORY ====================

  // Get medical history
  async getMedicalHistory(userId: string, petId: string) {
    const pet = await this.verifyOwnership(petId, userId);
    return {
      petId: pet._id,
      petName: pet.name,
      medicalHistory: pet.medicalHistory,
    };
  }

  // Add medical record
  async addMedicalRecord(
    userId: string,
    petId: string,
    addMedicalRecordDto: AddMedicalRecordDto,
  ) {
    const pet = await this.verifyOwnership(petId, userId);

    // ✅ FIX: Convert string dates to Date objects
    const medicalRecord = {
      _id: new Types.ObjectId(),
      date: new Date(addMedicalRecordDto.date), // ✅ Convert string to Date
      description: addMedicalRecordDto.description,
      veterinarian: addMedicalRecordDto.veterinarian || '',
      clinic: addMedicalRecordDto.clinic || '',
      diagnosis: addMedicalRecordDto.diagnosis || [],
      prescription: addMedicalRecordDto.prescription || [],
      documents: addMedicalRecordDto.documents || [],
      followUpDate: addMedicalRecordDto.followUpDate 
        ? new Date(addMedicalRecordDto.followUpDate) // ✅ Convert string to Date
        : null,
      cost: addMedicalRecordDto.cost || 0,
      isActive: true,
    };

    pet.medicalHistory.push(medicalRecord as any);
    await pet.save({ validateModifiedOnly: true });

    return {
      medicalRecord,
      pet,
    };
  }

  // ==================== PHOTOS ====================

  // Add photo
  async addPhoto(userId: string, petId: string, photoUrl: string) {
    const pet = await this.verifyOwnership(petId, userId);
    
    pet.photo = photoUrl;
    await pet.save({ validateModifiedOnly: true });

    return {
      message: 'Thêm ảnh thành công',
      data: pet,
    };
  }

  // Delete photo
  async deletePhoto(userId: string, petId: string) {
    const pet = await this.verifyOwnership(petId, userId);
    
    // ✅ FIX: Set to null instead of undefined
    pet.photo = null;
    await pet.save({ validateModifiedOnly: true });

    return {
      message: 'Xóa ảnh thành công',
      data: pet,
    };
  }
}